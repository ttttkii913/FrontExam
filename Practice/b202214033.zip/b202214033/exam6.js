let persons = [
    { name: "전우치", age: 19},
    { name: "이몽룡", age: 16}
];

console.log(persons);