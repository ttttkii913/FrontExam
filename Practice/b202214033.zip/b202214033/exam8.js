let persons1 = [
    { name: "전우치", age: 19},
    { name: "이몽룡", age: 16}
];

let persons2 = [
    { name: "홍길동", age: 16},
    { name: "임꺽정", age: 20}
];

persons2[0] = persons1[1];

console.log(persons1);
console.log(persons2);