let a = [[1, 2], [3, 4, 5]];
a[2] = a[1];

console.log(a);