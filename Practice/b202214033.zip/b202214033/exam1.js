let a = [1, 2];
let b = [3, 4];

console.log(a);
console.log(b);