let b = [1, 2];
let c = [3, 4, 5];
let a = [b, c];

console.log(a);
console.log(b);
console.log(c);